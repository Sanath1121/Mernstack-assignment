import exp from "express";
import {userModel} from '../models/userModel.js';
import {compare} from 'bcryptjs';
import { productModel } from "../models/productModel.js";


export const userApp=exp();

userApp.post("/users",async(req,res)=>{
    //get new user obj from req
    let userObj=req.body;
    //create new user Document
    let userDocument=new userModel(userObj);
    await userDocument.save();
    res.status(200).json({message:"new user added",payload:userDocument})
})

//Req to add product to cart
userApp.put("/user-cart/user-id/:uid/product-id/:pid",async(req,res)=>{
    let {uid,pid}=req.params;
    let user =await userModel.findById(uid);
    if(!user)
        return res.status(404).json({message:"Product not found"});
    let product=await productModel.findById(pid);
    user =await userModel.findByIdAndUpdate(uid,{$push:{cart:{product}}},{new:true});
    console.log(product)
    res.status(200).json({message:"Product added to cart",payload:user});
})

//Find user by id
userApp.get('/users/:id',async(req,res)=>{
    let objId=req.params.id;
    let user=await userModel.findById(objId).populate("cart.product");
    res.status(200).json({message:"User Found",payload:user})
})

